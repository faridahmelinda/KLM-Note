package com.example.klmnote;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder>{
    private ArrayList<Task> todoList;

    public RecyclerAdapter(ArrayList<Task> todoList) {
        this.todoList = todoList;
    }

    public class MyViewHolder extends  RecyclerView.ViewHolder{
        public final TextView subjectsTxt;
        public final TextView categoryTxt;
        public final TextView detailsTxt;
        public final TextView dateTxt;
        public final TextView timeTxt;

        public MyViewHolder(final View view) {
            super(view);
            subjectsTxt = view.findViewById(R.id.subjectsTxt);
            categoryTxt = view.findViewById(R.id.categoryTxt);
            detailsTxt = view.findViewById(R.id.detailsTxt);
            dateTxt = view.findViewById(R.id.dateTxt);
            timeTxt = view.findViewById(R.id.timeTxt);
        }
    }

    @NonNull
    @Override
    public RecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview, parent, false);
        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.MyViewHolder holder, int position) {
        String subjectsTask = todoList.get(position).getSubjectsTask();
        String categoryTask = todoList.get(position).getCategoryTask();
        String detailsTask = todoList.get(position).getDetailsTask();
        String dueDate = todoList.get(position).getDueDate();
        String dueTime = todoList.get(position).getDueTime();

        holder.subjectsTxt.setText(subjectsTask);
        holder.categoryTxt.setText(categoryTask);
        holder.detailsTxt.setText(detailsTask);
        holder.dateTxt.setText(dueDate);
        holder.timeTxt.setText(dueTime);
    }

    @Override
    public int getItemCount() {
        return todoList.size();
    }
}