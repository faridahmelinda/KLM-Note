package com.example.klmnote;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Task> todoList;
    private RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.tugasRecycleView);
        todoList = new ArrayList<>();

        OurData();
        setAdapter();
    }

    private void setAdapter() {
        RecyclerAdapter adapter = new RecyclerAdapter(todoList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    private void OurData() {
        todoList.add(new Task("PKN","Membuat Karya Tulis","Karya Tulis Mengenai Materi yang telah disampaikan","14/04/2021","23:59"));
        todoList.add(new Task("PKN","Membuat Karya Tulis","Karya Tulis Mengenai Materi yang telah disampaikan","14/04/2021","23:59"));
        todoList.add(new Task("PKN","Membuat Karya Tulis","Karya Tulis Mengenai Materi yang telah disampaikan","14/04/2021","23:59"));
        todoList.add(new Task("PKN","Membuat Karya Tulis","Karya Tulis Mengenai Materi yang telah disampaikan","14/04/2021","23:59"));
        todoList.add(new Task("PKN","Membuat Karya Tulis","Karya Tulis Mengenai Materi yang telah disampaikan","14/04/2021","23:59"));

    }


}