package com.example.klmnote;
import java.util.Date;

public class Task {
    private final String subjectsTask;
    private final String categoryTask;
    private final String detailsTask;
    private final String dueDate;
    private final String dueTime;

    public Task(String subjectsTask, String categoryTask, String detailsTask, String dueDate, String dueTime) {
        this.subjectsTask = subjectsTask;
        this.categoryTask = categoryTask;
        this.detailsTask= detailsTask;
        this.dueDate = dueDate;
        this.dueTime = dueTime;
    }

    public String getSubjectsTask() {

        return subjectsTask;
    }

    public String getCategoryTask() {

        return categoryTask;
    }

    public String getDetailsTask() {

        return detailsTask;
    }

    public String getDueDate() {

        return dueDate;
    }

    public String getDueTime() {

        return dueTime;
    }

}

